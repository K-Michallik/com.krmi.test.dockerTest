package com.ur.urcap.examples.dockerdaemon.impl;

public class UnknownResponseException extends Exception {
}
